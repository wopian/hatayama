const multiply = (x, y) => x * y;

if (typeof module !== 'undefined' && module.hasOwnProperty('exports')) {
  module.exports = multiply;
}
